import React from 'react'
import './RegisterNav.css'

const RegisterNav = () => {
  return (
    <>
        <div className="register-nav">
            <div className="logo text">
               <p>Logo</p>
              
            </div>
        </div>   
    
    </>


    
  )
}

export default RegisterNav